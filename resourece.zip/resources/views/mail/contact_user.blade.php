<!DOCTYPE html>
<html lang='en'>
<head>
	<title>Contact Us Email</title>
</head>
<body>
	<h1 style="text-align: center">Thnaks <?php echo $name; ?>! for Contacting Us</h1>

	<div>Our concern team  will get back to you soon</div>


</body>
</html>