<!DOCTYPE html>
<html lang='en'>
<head>
	<title>User Contact Us Email</title>
</head>
<body>
	<h1 style="text-align: center">Contact Us</h1>
	<div>Name: <?php echo $name; ?></div>
	<div>Email: <?php echo $email; ?></div>
	<div>Phone: <?php echo $phone; ?></div>
	<div>Message: <?php echo $msg; ?></div>
</body>
</html>