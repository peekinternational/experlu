<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<HTML>
<HEAD>
 <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
 <meta name="viewport" content="width=device-width, initial-scale=1">
<TITLE>bcl_1879666702.htm</TITLE>
<META name="generator" content="BCL easyConverter SDK 5.0.140">
<STYLE type="text/css">

body {margin-top: 0px;margin-left: 0px;}

#page_1 {position:relative; overflow: hidden;margin: 16px 0px 154px 25px;padding: 0px;border: none;width: 791px;}
#page_1 #id1_1 {border:none;margin: 0px 0px 0px 20px;padding: 0px;border:none;width: 771px;overflow: hidden;}
#page_1 #id1_2 {border:none;margin: 33px 0px 0px 20px;padding: 0px;border:none;width: 415px;overflow: hidden;}

#page_1 #p1dimg1 {position:absolute;top:27px;left:0px;z-index:-1;width:746px;height:756px;}
#page_1 #p1dimg1 #p1img1 {width:746px;height:756px;}




#page_2 {position:relative; overflow: hidden;margin: 47px 0px 452px 45px;padding: 0px;border: none;width: 771px;}

#page_2 #p2dimg1 {position:absolute;top:477px;left:0px;z-index:-1;width:726px;height:2px;font-size: 1px;line-height:nHeight;}
#page_2 #p2dimg1 #p2img1 {width:726px;height:2px;}




.ft0{font: 12px 'Helvetica';color: #666666;line-height: 15px;}
.ft1{font: 19px 'Helvetica';line-height: 22px;}
.ft2{font: 1px 'Helvetica';line-height: 1px;}
.ft3{font: 16px 'Helvetica';color: #666666;line-height: 18px;}
.ft4{font: 13px 'Helvetica';color: #57bcee;line-height: 16px;}
.ft5{font: 1px 'Helvetica';line-height: 12px;}
.ft6{font: 16px 'Helvetica';line-height: 18px;}
.ft7{font: 1px 'Helvetica';line-height: 11px;}
.ft8{font: 16px 'Helvetica';line-height: 19px;}

.p0{text-align: left;padding-left: 445px;margin-top: 0px;margin-bottom: 0px;}
.p1{text-align: left;padding-left: 120px;margin-top: 0px;margin-bottom: 0px;}
.p2{text-align: left;padding-left: 120px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p3{text-align: left;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p4{text-align: left;padding-left: 45px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p5{text-align: left;margin-top: 56px;margin-bottom: 0px;}
.p6{text-align: right;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p7{text-align: left;margin-top: 52px;margin-bottom: 0px;}
.p8{text-align: left;margin-top: 57px;margin-bottom: 0px;}
.p9{text-align: left;padding-right: 60px;margin-top: 32px;margin-bottom: 0px;}

.td0{padding: 0px;margin: 0px;width: 245px;vertical-align: bottom;}
.td1{padding: 0px;margin: 0px;width: 481px;vertical-align: bottom;}
.td2{border-bottom: #eeeeee 1px solid;padding: 0px;margin: 0px;width: 245px;vertical-align: bottom;}
.td3{border-bottom: #eeeeee 1px solid;padding: 0px;margin: 0px;width: 481px;vertical-align: bottom;}
.td4{padding: 0px;margin: 0px;width: 241px;vertical-align: bottom;}
.td5{padding: 0px;margin: 0px;width: 67px;vertical-align: bottom;}
.td6{padding: 0px;margin: 0px;width: 290px;vertical-align: bottom;}
.td7{padding: 0px;margin: 0px;width: 125px;vertical-align: bottom;}
.td8{padding: 0px;margin: 0px;width: 436px;vertical-align: bottom;}
.td9{border-bottom: #eeeeee 1px solid;padding: 0px;margin: 0px;width: 290px;vertical-align: bottom;}
.td10{border-bottom: #eeeeee 1px solid;padding: 0px;margin: 0px;width: 436px;vertical-align: bottom;}

.tr0{height: 28px;}
.tr1{height: 35px;}
.tr2{height: 66px;}
.tr3{height: 12px;}
.tr4{height: 44px;}
.tr5{height: 29px;}
.tr6{height: 30px;}
.tr7{height: 71px;}
.tr8{height: 11px;}
.tr9{height: 22px;}
.tr10{height: 26px;}
.tr11{height: 68px;}

.t0{width: 726px;font: 16px 'Helvetica';}
.t1{width: 308px;margin-top: 37px;font: 16px 'Helvetica';}
.t2{width: 415px;font: 16px 'Helvetica';}

</STYLE>
</HEAD>
  <?php
                    $path = public_path('/frontend-assets/logo.png');
                    $type = pathinfo($path, PATHINFO_EXTENSION);
                    $data = file_get_contents($path);
                    $base64 = 'data:image/' . $type . ';base64,' . base64_encode($data);
           
    ?>
<BODY>
<DIV id="page_1">
<DIV id="p1dimg1">
</DIV>


<DIV id="id1_1">
<img src="{{ $base64}}" style="width:100%; max-width:300px;">
<P class="p0 ft0">Experlu | 1635 Market St #1600 | 19103 Philadelphia</P>
<P class="p0 ft0">PA | | +1 (267) 8000215</P>
<P class="p1 ft1">{{$data->job_title}}</P>
<TABLE cellpadding=0 cellspacing=0 class="t0">
<TR>
	<TD class="tr0 td0"><P class="p2 ft1">{{$data->services}}</P></TD>
	<TD class="tr0 td1"><P class="p3 ft2">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr1 td0"><P class="p3 ft3">{{$data->location}} ·#{{$data->job_id}}</P></TD>
	<TD class="tr1 td1"><P class="p3 ft2">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr2 td0"><P class="p3 ft4">Contact information</P></TD>
	<TD class="tr2 td1"><P class="p3 ft2">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr3 td2"><P class="p3 ft5">&nbsp;</P></TD>
	<TD class="tr3 td3"><P class="p3 ft5">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr4 td0"><P class="p3 ft6">Name:</P></TD>
	<TD class="tr4 td1"><P class="p4 ft6">{{$data->customer_name}}</P></TD>
</TR>
<TR>
	<TD class="tr5 td0"><P class="p3 ft6">Phone:</P></TD>
	<TD class="tr5 td1"><P class="p4 ft6">{{$data->phone_number}}</P></TD>
</TR>
<TR>
	<TD class="tr6 td0"><P class="p3 ft6">Location:</P></TD>
	<TD class="tr6 td1"><P class="p4 ft6">{{$data->city}}</P></TD>
</TR>
<TR>
	<TD class="tr5 td0"><P class="p3 ft6">Company name:</P></TD>
	<TD class="tr5 td1"><P class="p4 ft6">{{$data->customer_name}}</P></TD>
</TR>
<TR>
	<TD class="tr6 td0"><P class="p3 ft6">Vat number:</P></TD>
	<TD class="tr6 td1"><P class="p4 ft3">No vat number specified</P></TD>
</TR>
<TR>
	<TD class="tr7 td0"><P class="p3 ft4">Services needed</P></TD>
	<TD class="tr7 td1"><P class="p3 ft2">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr8 td2"><P class="p3 ft7">&nbsp;</P></TD>
	<TD class="tr8 td3"><P class="p3 ft7">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr4 td0"><P class="p3 ft6">Annual accounts</P></TD>
	<TD class="tr4 td1"><P class="p3 ft2">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr6 td0"><P class="p3 ft6">Corporation tax</P></TD>
	<TD class="tr6 td1"><P class="p3 ft2">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr5 td0"><P class="p3 ft6">Confirmation statement</P></TD>
	<TD class="tr5 td1"><P class="p3 ft2">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr6 td0"><P class="p3 ft6">Self Assessment tax return</P></TD>
	<TD class="tr6 td1"><P class="p3 ft2">&nbsp;</P></TD>
</TR>
</TABLE>
<P class="p5 ft4">Case highlights</P>
<TABLE cellpadding=0 cellspacing=0 class="t1">
<TR>
	<TD class="tr9 td4"><P class="p3 ft6">Annual amount of annexes</P></TD>
	<TD class="tr9 td5"><P class="p6 ft6">50</P></TD>
</TR>
</TABLE>
<P class="p7 ft4">About the client</P>
</DIV>
<DIV id="id1_2">
<TABLE cellpadding=0 cellspacing=0 class="t2">
<TR>
	<TD class="tr10 td6"><P class="p3 ft6">Experience as a business owner</P></TD>
	<TD class="tr10 td7"><P class="p3 ft6">Some experience</P></TD>
</TR>
<TR>
	<TD class="tr10 td6"><P class="p3 ft6">Vision for future</P></TD>
	<TD class="tr10 td7"><P class="p3 ft6">Stable</P></TD>
</TR>
<TR>
	<TD class="tr6 td6"><P class="p3 ft6">Has had previous partner</P></TD>
	<TD class="tr6 td7"><P class="p3 ft6">No</P></TD>
</TR>
</TABLE>
</DIV>
</DIV>
<DIV id="page_2">
<DIV id="p2dimg1">
<IMG src="data:image/jpg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCAACAtUDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD26iiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD//2Q==" id="p2img1"></DIV>


<TABLE cellpadding=0 cellspacing=0 class="t0">
<TR>
	<TD class="tr10 td6"><P class="p3 ft6">Reason of change</P></TD>
	<TD class="tr10 td8"><P class="p3 ft6">Price</P></TD>
</TR>
<TR>
	<TD class="tr11 td6"><P class="p3 ft4">About the bookkeeping</P></TD>
	<TD class="tr11 td8"><P class="p3 ft2">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr8 td9"><P class="p3 ft7">&nbsp;</P></TD>
	<TD class="tr8 td10"><P class="p3 ft7">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr4 td6"><P class="p3 ft6">State of the bookkeeping</P></TD>
	<TD class="tr4 td8"><P class="p3 ft6">Bookkept</P></TD>
</TR>
<TR>
	<TD class="tr7 td6"><P class="p3 ft4">Preferences for the partner</P></TD>
	<TD class="tr7 td8"><P class="p3 ft2">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr8 td9"><P class="p3 ft7">&nbsp;</P></TD>
	<TD class="tr8 td10"><P class="p3 ft7">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr4 td6"><P class="p3 ft6">Communication style</P></TD>
	<TD class="tr4 td8"><P class="p3 ft6">Formal</P></TD>
</TR>
<TR>
	<TD class="tr6 td6"><P class="p3 ft6">Partner should be (1)</P></TD>
	<TD class="tr6 td8"><P class="p3 ft6">Focused on couseling</P></TD>
</TR>
<TR>
	<TD class="tr5 td6"><P class="p3 ft6">Partner should be (2)</P></TD>
	<TD class="tr5 td8"><P class="p3 ft6">Experienced</P></TD>
</TR>
<TR>
	<TD class="tr6 td6"><P class="p3 ft6">Partner should be (3)</P></TD>
	<TD class="tr6 td8"><P class="p3 ft6">Price transparent</P></TD>
</TR>
<TR>
	<TD class="tr5 td6"><P class="p3 ft6">Material is delivered</P></TD>
	<TD class="tr5 td8"><P class="p3 ft6">Mostly digital</P></TD>
</TR>
</TABLE>
<P class="p8 ft4">Case description</P>
<P class="p9 ft8">{{$data->quote}}</P>
</DIV>
</BODY>
</HTML>
